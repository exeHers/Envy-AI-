"""
Web dashboard for Envy.
"""
