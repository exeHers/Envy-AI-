# Models Directory

Runtime models are downloaded on demand via `scripts/download_models.py` or `scripts/download_models.sh`.

Default (balanced/low) download: Vosk small English model (~50 MB).

Power profile downloads Whisper small + llama.cpp GGUF weights. These are optional and not bundled to keep the repository lightweight.
