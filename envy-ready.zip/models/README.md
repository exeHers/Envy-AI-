Run `scripts/download_models.sh --vosk` (Linux/macOS) or `scripts\download_models.ps1 -Vosk` (Windows) to populate this directory with required speech and language models.
