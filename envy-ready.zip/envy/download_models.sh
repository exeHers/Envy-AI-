#!/bin/bash
# Download required models

set -e

MODELS_DIR="models"
mkdir -p "$MODELS_DIR"

echo "Downloading VOSK model..."
cd "$MODELS_DIR"
if [ ! -d "vosk-model-small-en-us-0.22" ]; then
    wget -q https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.22.zip || {
        echo "Warning: Failed to download VOSK model"
        exit 1
    }
    unzip -q vosk-model-small-en-us-0.22.zip
    rm vosk-model-small-en-us-0.22.zip
fi

echo "VOSK model downloaded"
echo ""
echo "Note: Whisper models download automatically on first use"
echo "For LLM: Download a quantized model (e.g., llama-2-7b-chat-q4_0.gguf) to models/"
