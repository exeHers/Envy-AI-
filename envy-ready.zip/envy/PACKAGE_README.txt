Envy Personal Assistant - Ready Package
========================================

Quick Start:
1. Extract this package
2. Run: ./install_envy.sh (Linux) or install_envy.bat (Windows)
3. Run: ./run_envy_local.sh --profile balanced

For detailed instructions, see:
- README.md
- docs/install-linux.md
- docs/install-windows.md

Models:
- VOSK model: Run ./download_models.sh
- Whisper: Downloads automatically
- LLM: Download manually or use remote free endpoint

Web Dashboard: http://127.0.0.1:8080
