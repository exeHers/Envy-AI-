Runtime data (reminders, temporary audio, logs) will be stored here at runtime. Safe to delete between runs.
